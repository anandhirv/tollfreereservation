
app.controller('NumberPortabilityCheckEligibilityCtrl',function ($scope, $http,ModalService) {
		
	
	$scope.Number = null;
	$scope.providerOld = null;
	$scope.providerNew = null;
	
	$scope.clear = function(){
		$scope.Number = null;		
	};
	
	$scope.users= [];
	
	$http({
	    url:'https://nodejsbci012.mybluemix.net/getWorkListByStatus?status=Open',
	    method: "Get"
		})
		.then(function (response) {	
			if (response.data){						
				var obj = JSON.parse(response.data);
				if(obj.docs){
					var messageObj = obj.docs;
					//var users = [];
					if(messageObj.length > 0){
		                for (var i = 0; i < messageObj.length; i++) {
		                	 $scope.users.push({number:messageObj[i].Tollfreeno,serviceprovider:messageObj[i].ServiceProvider,assigneddate:messageObj[i].AssignedDate,status:messageObj[i].Status});
		                }	
		                
					}
				}
				$http({
				    url:'https://nodejsbci012.mybluemix.net/getWorkListByStatus?status=RequestInitiated',
				    method: "Get"
					})
					.then(function (response) {	
						if (response.data){						
							var obj = JSON.parse(response.data);
							if(obj.docs){
								var messageObj = obj.docs;
								//var users = [];
								if(messageObj.length > 0){
					                for (var i = 0; i < messageObj.length; i++) {
					                	$scope.users.push({number:messageObj[i].Tollfreeno,serviceprovider:messageObj[i].ServiceProvider,assigneddate:messageObj[i].AssignedDate,status:messageObj[i].Status});
					                }
					                
								}
							}
						}
					},function (response) {	
						console.log("failed : ", response);	
					});
			}
		},function (response) {	
			console.log("failed : ", response);	
		});
});
			